<!-- Jacob Abell, Maria Peterson, Madeline Dietrich
	 Project 5
	 Clock Game
	 12/06/18 -->
<?php
	session_start();
?>
<!DOCTYPE html>
<html lang = "en">
	<header>
		<title>Player Stats</title>
		<link rel = "stylesheet" type = "text/css" href = "Proj_5.css">
	</header>
	
	<body>
		<div class = "heading">
			<h1>Player Stats</h1>
		</div>
		<div id = "stats">
			<h3>Games Won: </h3>
			<h3>Games Lost: </h3>
			<h3>Win Percentage: </h3>
			<h3>Total Games Played: </h3>
		</div>
		<div id = "buttons">
			<button class = "btn" onclick = "location.href = 'index.php'" type = "button">RETURN TO GAME</button>
		</div>
	</body>
</html>
